<?php
// Keep your Stripe API key protected by including it as an environment variable
// or in a private script that does not publicly expose the source code.

// This is your test secret API key.
$stripeSecretKey = 'sk_test_51MXJCFJPA0w1eqNpNtvirNq7WGLx2kj9BBs0f38bTPgPbwDDFhkuGoTM41pLmxEhT1SGFRY9Dsxgcwffh4YuDR8M00qjZR13id';